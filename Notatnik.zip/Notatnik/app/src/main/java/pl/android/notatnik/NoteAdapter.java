package pl.android.notatnik;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.ViewHolder> {
    private List<Note> noteList;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
    private ItemClickListener itemClickListener;

    public NoteAdapter(List<Note> note) {
        noteList = note;
    }

    public void setOnItemClickListener(ItemClickListener listener){
        this.itemClickListener = listener;
    }

    public void filterList(ArrayList<Note> filteredList) {
        noteList = filteredList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        final ViewHolder VH = new ViewHolder(view, itemClickListener);
        return VH;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        dateFormat.format(noteList.get(position).getTimestamp());
        holder.name.setText(noteList.get(position).getText());
        holder.time.setText(dateFormat.format(noteList.get(position).getTimestamp()));
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView name, time;
        Button delete;
        CheckBox done;
        ConstraintLayout layout;
        ItemClickListener listener;

        ViewHolder(View root, ItemClickListener listener) {
            super(root);
            this.name = root.findViewById(R.id.tv_name);
            this.time = root.findViewById(R.id.tv_time);
            this.done = root.findViewById(R.id.cb_done);
            this.delete = root.findViewById(R.id.btnDelete);
            this.layout = root.findViewById(R.id.itemLayout);
            this.listener = listener;
            delete.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (listener != null) {
                listener.onItemClick(view, getLayoutPosition());
            }
        }
    }
}
