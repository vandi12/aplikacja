package pl.android.notatnik;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View view, int pos);
}
