package pl.android.notatnik;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AddNoteDialog.PassDataListener {

    RecyclerView list;
    FloatingActionButton fab;
    EditText filterLabel;
    private NoteAdapter adapter;
    List<Note> noteList = new ArrayList<Note>();
    private ArrayList<Note> filteredList;

    MyDatabase myDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDatabase = MyDatabase.getAppDatabase(getApplicationContext());

        findViews();
        fab.setOnClickListener(this);
        filterLabel.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (!editable.toString().equals("")) {
                    filterList(editable.toString());
                } else {
                    filteredList.clear();
                    adapter.filterList((ArrayList<Note>) noteList);
                }
            }
        });

        noteList = myDatabase.noteDAO().getAllNotes();
    }

    @Override
    public void onResume() {
        super.onResume();
        adapter = new NoteAdapter(noteList);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        list.setLayoutManager(linearLayoutManager);
        list.setHasFixedSize(true);
        list.setAdapter(adapter);

        adapter.setOnItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClick(View view, int pos) {
                myDatabase.noteDAO().delete(noteList.get(pos));
                noteList.remove(pos);
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    private void findViews() {
        list = findViewById(R.id.recycler_list);
        fab = findViewById(R.id.fab_btn);
        filterLabel = findViewById(R.id.etFilter);
    }

    private void filterList(String input) {
        filteredList = new ArrayList<>();
        for (Note note : noteList) {
            if (note.text.toLowerCase().contains(input.toLowerCase())) {
                filteredList.add(note);
            }
        }
        adapter.filterList(filteredList);
    }

    @Override
    public void onClick(View view) {
        AddNoteDialog dialog = new AddNoteDialog();
        dialog.show(getSupportFragmentManager(), "add note dialog");
    }

    public Note generateNote(String input) {
        long currentTime = System.currentTimeMillis();
        Note note = new Note();
        note.setText(input);
        note.setTimestamp(currentTime);
        myDatabase.noteDAO().insert(note);
        return note;
    }

    @Override
    public void passData(String input) {
        noteList.add(generateNote(input));
        adapter.notifyDataSetChanged();
    }
}

